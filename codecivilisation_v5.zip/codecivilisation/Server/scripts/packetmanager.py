import copy
import useraction
from datetime import datetime
import random

def userAction(client_NAME,client_PASSWORD,client_ACTION,map_data,player_data,server_config):
    # client_NAME: string (username)
    # client_PASSWORD: string (password)

    if (client_NAME == "register"):
        success, player_data = register(client_PASSWORD,client_ACTION, player_data, map_data) # since username is register, all other
        # variables are shifted to the right by one. You probably won't need to deal with this part anyways.

        player_data[client_PASSWORD]["timestamp"] = getTimeStamp()

        
        
        if success:
            return True, map_data, player_data, {"login_status":"registered", "user_packet_timeout":server_config["user_packet_timeout"]}
        else:
            return False, map_data, player_data, {"login_status":"could not register", "user_packet_timeout":server_config["user_packet_timeout"]}

    if auth(client_NAME, client_PASSWORD, player_data):
        #client authenticated.
        if (client_ACTION == "refresh"): # client is just refreshing the connection. no need to update timestamp.
            return True, map_data, player_data, {"login_status":"successful", "user_packet_timeout":server_config["user_packet_timeout"]}
        
        if (getDifference(player_data[client_NAME]["timestamp"], getTimeStamp()) >= int(server_config["user_packet_timeout"])):
        
            player_data[client_NAME]["timestamp"] = getTimeStamp()
        
            map_data, player_data = useraction.handle(client_NAME, client_ACTION, map_data,player_data,server_config)
        
            return True, map_data, player_data, {"login_status":"successful", "user_packet_timeout":server_config["user_packet_timeout"]}
        else:
            player_data[client_NAME]["timestamp"] = getTimeStamp()
            return False, map_data, player_data, {"login_status":"too many packets", "user_packet_timeout":server_config["user_packet_timeout"]}
        
    
    return False, map_data, player_data, {"login_status":"failed", "user_packet_timeout":server_config["user_packet_timeout"]}
    

def validPlayer(name, player_data):
    try:
        player_data[name] # is this user already registered?
    except KeyError:
        return False
    else:
        return True


def auth(name,password,player_data):
    
    if validPlayer(name,player_data):
        if (player_data[name]["password"] == password):
            return True
    return False

def register(name,password,player_data, map_data):
    if validPlayer(name,player_data): # is this user already registered?
        return False, player_data # Yes, they are (or something went terribly wrong...)
    player_data[name] = newPlayer(password, map_data)
    return True, player_data

def newPlayer(password, map_data):

    x = random.randrange(map_data["dimensions"])
    y = random.randrange(map_data["dimensions"])

    while not map_data["tiles"][x][y] == 0: # Make sure player spawns on ground (Tile id 0)
        x = random.randrange(0, map_data["dimensions"])
        y = random.randrange(0, map_data["dimensions"])
    return {"password":password, "position":{"x":x,"y":y},"inventory":[]}
    

def nearbyPlayers(name,player_data,server_config):
    returnjson = {}
    if validPlayer(name,player_data):
        local_player = player_data[name]
        for player in player_data:
            player_i = player_data[player]
            if (abs(int(local_player["position"]["x"]) - int(player_i["position"]["x"])) <= int(server_config["sight_range"])):
                if (abs(int(local_player["position"]["y"]) - int(player_i["position"]["y"])) <= int(server_config["sight_range"])):
                    returnjson[player] = copy.copy(player_i) # copy object so we can set password in the next line without changing the original
                    returnjson[player]["password"] = "" # delete password so that others can't see it.
    return returnjson

def getTimeStamp():
    dateTimeObj = datetime.now()
    timestampStr = dateTimeObj.strftime("%Y-%m-%d %H:%M:%S")
    return timestampStr

def getDifference(t1,t2):
    fmt = '%Y-%m-%d %H:%M:%S'
    tstamp1 = datetime.strptime(t1, fmt)
    tstamp2 = datetime.strptime(t2, fmt)

    if tstamp1 > tstamp2:
        td = tstamp1 - tstamp2
    else:
        td = tstamp2 - tstamp1
    return int(round(td.total_seconds()))

def sliceMapData(map_data, player_data, pname):
    px = player_data[pname]["position"]["x"]
    py = player_data[pname]["position"]["y"]

    map_data_c = copy.copy(map_data) # copy map_data for use
    print(len(map_data_c))
    size = 14

    tiles = copy.copy(map_data_c["tiles"])
    
    map_data_c["tiles"] = [[0]*14 for _ in range(14)]

    
    
    for x in range(0,14):
        for y in range(0,14):
            if px-6+x < 0 or px-6+x >= map_data_c["dimensions"]:
                map_data_c["tiles"][x][y] = 2 # if out of world, return water. (X-axis)
            elif py-6+y < 0 or py-6+y >= map_data_c["dimensions"]:
                map_data_c["tiles"][x][y] = 2 # if out of world, return water. (Y-axis)
            else:
                map_data_c["tiles"][x][y] = tiles[px-6+x][py-6+y] # return the actual tile ID
    
    return map_data_c, player_data # map_data, player_data = map_data_slice(map_data, player_data, client_NAME)
            
