from threading import Timer,Thread,Event
from http.server import BaseHTTPRequestHandler, HTTPServer


import copy
import json
import os
working_dir = os.getcwd(); # Working directory
import sys
#insert scripts folder into python paths
sys.path.insert(1, working_dir + '/scripts')

import mapgenerator
import packetmanager

# LOAD SAVE FILES
print ("╓ [LOADING SAVE FILES]")
map_data = {}
player_data = {}
server_config = {}


print("╠═ Loading players.json from /saves.")
with open(working_dir + '/saves/players.json') as json_file: # load player data from saves
    player_data = json.load(json_file)

# Player data format:
#   [json key] - name (the player name is the json key. Names have to be unique)
#   password: string (needed for login, makes sure names are unique)
#   position: json
#       x: int (X position of player on the map)
#       y: int (Y position of player on the map)
#       inventory: array (list of item ids in player's inventory. Currently unused)

print("╠═ Loading server_config.json from /.")
with open(working_dir + '/server_config.json') as json_file: # load map from saves
    server_config = json.load(json_file)

# Server config format:
#   address: string (server address, run ipconfig to get local address)
#   port: int (server port, choose an open port that is not blocked by firewall or antivirus)
#   user_packet_timeout: int (minimum time that players have to wait before sending another packet in milliseconds
# this setting may also define the speed of the game as players will be able to send their actions faster. Recommended to leave it on default.

print("╠═ Loading map.json from /saves.")
with open(working_dir + '/saves/map.json') as json_file: # load map from saves
    map_data = json.load(json_file)

# Map data format:
#   tiles: 2d array
#   dimensions: integer (always square map)
#   isEmpty: boolean (is map empty? generating a map will set it to false. Defaults to true)

if (map_data["isEmpty"]):
    print("╠═ Map is not generated.")
    # [TODO] generate map
    new_map = mapgenerator.generateMap(map_data, server_config)
    map_data = new_map

print ("╙ [SAVE FILES LOADED SUCCESSFULLY]")

# IMPLEMENT AUTOSAVE

class AutoSave(Thread):
    def __init__(self, event):
        Thread.__init__(self)
        self.stopped = event

    def run(self):
        global server_config
        while not self.stopped.wait(int(server_config["autosave_delay"])):
            print("$Server> Autosaving. DO NOT EXIT NOW.")
            global map_data
            global player_data
            with open(working_dir + '/saves/map.json', 'w') as out_file:
                json.dump(map_data, out_file)

            with open(working_dir + '/saves/players.json', 'w') as out_file:
                json.dump(player_data, out_file)
            print("$Server> Saved. You can exit now.")

# Start autosave thread
stopFlag = Event()
thread = AutoSave(stopFlag)
thread.start()

print ("╓ [STARTING SERVER]")

# HTTP REQUEST HANDLER.
#   Returns world and entity data to players after they send action packets.
class RequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        global map_data
        global player_data
        global server_config
        
        clientPacket = self.path;
        if len(self.path.split("/")) >= 4:
            client_NAME = clientPacket.split("/")[1]
            client_PASSWORD = clientPacket.split("/")[2]
            client_ACTION = clientPacket.split("/")[3]
            
            if (client_NAME == ""):
                return
            if (client_PASSWORD == ""):
                return

            authenticated, new_map_data, new_player_data, packet = packetmanager.userAction(client_NAME,client_PASSWORD,client_ACTION,map_data,player_data,server_config)
            # packetmanager.userAction authenticates the user, handles the action and returns the changes that were made,
            # along with the packet that will be sent to the user.

            map_data = new_map_data
            player_data = new_player_data

            packet["map_data"] = {}
            packet["player_data"] = {}

            if (authenticated):
                if client_NAME == "register": # since name in the PATH is replaced by "register", variables are shifted to the right by one.
                    packet["map_data"], temp = packetmanager.sliceMapData(map_data, player_data, client_PASSWORD)
                    packet["player_data"] = packetmanager.nearbyPlayers(client_PASSWORD, player_data, server_config)
                else:
                    packet["map_data"], temp = packetmanager.sliceMapData(map_data, player_data, client_NAME)
                    packet["player_data"] = packetmanager.nearbyPlayers(client_NAME, player_data, server_config)
            
            
        
            print ("$" + client_NAME + "> " + client_ACTION)
        
            self.protocol_version = "HTTP/1.1"
        
            self.send_response(200)
            self.send_header("Content-Length", len(json.dumps(packet)))
            self.end_headers()
            self.wfile.write(bytes(json.dumps(packet), "utf8"))
        
        return
    def log_message(self, format, *args): # disable logging every request.
        return

def run():
    server = (server_config["address"], int(server_config["port"]))
    httpd = HTTPServer(server, RequestHandler)
    print ("╙ Server started on: " + server_config["address"] + ":" + str(server_config["port"]))
    httpd.serve_forever()
run()


# LIST OF [TODO]
# [TODO] Use locks for async functions.
# This has been tested and it is currently not prioritized but I will implement it later.
# No, it did not cause a glitch.
