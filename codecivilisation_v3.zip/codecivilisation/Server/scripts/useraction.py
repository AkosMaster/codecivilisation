def handle(client_NAME, client_ACTION, map_data,player_data,server_config):
    local_player = player_data[client_NAME]

    splitAction = client_ACTION.split("-"); # split by '-' character

    if (splitAction[0] == "move"):
        
        vectorDirection = getDirection(splitAction[1])

        newX = local_player["position"]["x"] + vectorDirection["x"]
        newY = local_player["position"]["y"] + vectorDirection["y"]

        if validTile(newX,newY,map_data, player_data):
            local_player["position"]["x"] += vectorDirection["x"]
            local_player["position"]["y"] += vectorDirection["y"]

    player_data[client_NAME] = local_player # Just to be sure.

    return map_data, player_data


def getDirection(dir): # Get direction by name.
    if (dir == "up"):
        return {"x":0, "y":-1}
    if (dir == "down"):
        return {"x":0, "y":1}
    if (dir == "left"):
        return {"x":-1, "y":0}
    if (dir == "right"):
        return {"x":1, "y":0}
    return {"x":0, "y":0}

def validTile (x,y,map, players):
    try:
        map["tiles"][x][y]
    except:
        return False
    else:
        for name in players:
            if (players[name]["position"]["x"] == x and players[name]["position"]["y"] == y):
                return False # if there is a player there already, you cant move there.
        if map["tiles"][x][y] == 0: # Tile id 0 = Ground
            return True
        return False
