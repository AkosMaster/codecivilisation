import random
import copy

def generateMap(map_data,server_config):
    print("╠═ Generating map.")
    
    map_data["tiles"] = [ [0]*int(map_data["dimensions"]) for _ in range(int(map_data["dimensions"])) ]

    for x in range(len(map_data["tiles"])):
        for y in range(len(map_data["tiles"][x])):
            if x == 0 or y == 0 or x == int(map_data["dimensions"])-1 or y == int(map_data["dimensions"])-1:
                map_data["tiles"][x][y] = 2 # Tile ID 2 = water
                # Place water on edges of the map

    for i in range(round(int(map_data["dimensions"])*int(map_data["dimensions"])/int(map_data["tree_rate"]))): # tree count = tile count / tree rate
        map_data["tiles"][random.randrange(1,int(map_data["dimensions"])-1)][random.randrange(1,int(map_data["dimensions"])-1)] = 1 # Place trees at random places
        # Make sure trees can't spawn at edges
    map_data["isEmpty"] = False;
    
    print("╠═ Map generation finished.")
    return map_data
