import tkinter
import cv2
import PIL.Image, PIL.ImageTk
import os
import numpy as np

# [WARNING]
# PLEASE DO NOT EDIT THIS SCRIPT
# AS EVEN THE AUTHOR DOESN'T FULLY UNDERSTAND HOW
# IT WORKS. GOOD LUCK!

working_dir = os.getcwd(); # Working directory

size = 31 # how many tiles should it draw horizontally / vertically

local_player_img = cv2.imread(working_dir + "/graphics/units/local_player.png", cv2.IMREAD_UNCHANGED)
enemy_player_img = cv2.imread(working_dir + "/graphics/units/enemy_player.png", cv2.IMREAD_UNCHANGED)
ground_tile_img = cv2.cvtColor(cv2.resize(cv2.imread(working_dir + "/graphics/map_tiles/tile101.png"), (32,32)),cv2.COLOR_BGR2BGRA)
tree_tile_img = cv2.cvtColor(cv2.resize(cv2.imread(working_dir + "/graphics/map_tiles/tile081.png"), (32,32)),cv2.COLOR_BGR2BGRA)
water_tile_img = cv2.cvtColor(cv2.resize(cv2.imread(working_dir + "/graphics/map_tiles/tile161.png"), (32,32)),cv2.COLOR_BGR2BGRA)

tiles = [ground_tile_img, tree_tile_img, water_tile_img]

def draw(server_data, client_config):
    global tiles
    global size
    global local_player_img
    global enemy_player_img
    local_player = server_data["player_data"][client_config["username"]]

    background = np.zeros(shape=[16*size, 16*size, 4], dtype=np.uint8) # Start with empty bg.

    x_offset_mid=y_offset_mid=15*16 - 8
    
    for x in range(0, 13): # len(server_data["map_data"]["tiles"]
        for y in range(0, 13):
            
                tile_img = tiles[server_data["map_data"]["tiles"][x][y]]
                    
                x_offset_p=(x)*32 + 32 + 8 # + x_offset_mid
                y_offset_p=(y)*32 + 32 + 8 # + y_offset_mid
                drawOnImg(background, tile_img, x_offset_p, y_offset_p)

    
    drawOnImg(background, local_player_img, x_offset_mid, y_offset_mid)

    for enemy_name in server_data["player_data"]:
        if not enemy_name == client_config["username"]:
            enemy = server_data["player_data"][enemy_name]

            if abs(enemy["position"]["x"] - local_player["position"]["x"]) < 7:
                if abs(enemy["position"]["y"] - local_player["position"]["y"]) < 7:
                    x_offset_p=(enemy["position"]["x"] - local_player["position"]["x"])*32 + x_offset_mid
                    y_offset_p=(enemy["position"]["y"] - local_player["position"]["y"])*32 + y_offset_mid
            
                    drawOnImg(background, enemy_player_img, x_offset_p, y_offset_p)
    
    cv2.imshow("CodeCivilisation", background)
    
    return

def drawOnImg(bg, img, x_offset, y_offset):

    y1, y2 = y_offset, y_offset + img.shape[0]
    x1, x2 = x_offset, x_offset + img.shape[1]

    alpha_s = img[:, :, 3] / 255.0
    alpha_l = 1.0 - alpha_s

    for c in range(0, 3):
        bg[y1:y2, x1:x2, c] = (alpha_s * img[:, :, c] + alpha_l * bg[y1:y2, x1:x2, c])

    return bg
    
