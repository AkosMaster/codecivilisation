def process(server_data, client_config):

    local_player = server_data["player_data"][client_config["username"]]

    

    # There you can write your own script.
    # Some tips:
    # server_data["player_data"][client_config["username"]] is you local player.
    # server_data["player_data"][username] is the player with the specified username
    # you can loop through server_data["player_data"] to get nearby players
    # server_data["map_data"]["tiles"] contains only a 13*13 area around you player (with you being in the middle, [6][6])
    
    print ("Coordinates: X: " + str(local_player["position"]["x"]) + " Y: " + str(local_player["position"]["y"]))

    print(server_data["map_data"]["tiles"][6][6]) # this will print the ID of the tile you are standin' on. Not that useful.
    
    return "move-left" # move to your left.

    return "no_action" # RETURN CLIENT ACTION.

# ACTIONS:
# move-[direction] : directions: up, down, left, right
