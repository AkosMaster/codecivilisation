import requests
import time
import copy
import json
import os
import sys
import cv2
working_dir = os.getcwd(); # Working directory
sys.path.insert(1, working_dir + '/userscript') # Insert userscript folder into python path
sys.path.insert(1, working_dir + '/graphics') # Insert graphics folder into python path

import draw_world
import userscript # import user module

def saveConfig(data):
    with open(working_dir + '/client_config.json', 'w') as out_file:
        json.dump(data, out_file)


print ("╓ [LOADING SAVE FILES]")
client_config = {}

print("╠═ Loading client_config.json from /.")
with open(working_dir + '/client_config.json') as json_file: # load map from saves
    client_config = json.load(json_file)

if (client_config["username"] == ""):
    print("╠═ [ALERT] Username is empty.")
    print("╠═ [ERROR] Username cannot be empty.")
    exit()

if (client_config["password"] == ""):
    print("╠═ [ALERT] Password is empty.")
    print("╠═ [ERROR] Password cannot be empty.")
    exit()

if (client_config["server"] == ""):
    print("╠═ [ALERT] Server address is empty.")
    print("╠═ [ERROR] Server address cannot be empty.")
    exit()

if (client_config["port"] == ""):
    print("╠═ [ALERT] Server port is empty.")
    print("╠═ [ERROR] Server port cannot be empty. (Default is 2000)")
    exit()
    
print ("╙ [SAVE FILES LOADED SUCCESSFULLY]")

URL = client_config["server"] + ":" + client_config["port"]

if not (client_config["registered"]):
    print("╓ Registering to server.")
    r = requests.get(url = (URL + "/register/" + client_config["username"] + "/" + client_config["password"])).json()
    print("╠═ " + r["login_status"])
    if (r["login_status"] == "registered"):
        client_config["registered"] = True
        saveConfig(client_config)
        print("╙ Successfully registered.")
    else:
        print("╙ Could not register to server. (Are you registered already?)")
        exit()

server_config_raw = requests.get(url = (URL + "/" + client_config["username"] + "/" + client_config["password"] + "/refresh")).json()
server_config = {}
server_config["user_packet_timeout"] = copy.copy(int(server_config_raw["user_packet_timeout"]))

while 1: # main loop

    time.sleep(server_config["user_packet_timeout"]) # Sleep before continuing loop to prevent getting "too many packets" error.
    server_data = requests.get(url = (URL + "/" + client_config["username"] + "/" + client_config["password"] + "/refresh")).json() # send refresh packet. this will not
    # update you timestamp so you can send movement packets immediately after
    
    action = userscript.process(copy.copy(server_data), copy.copy(client_config)) # hand control to user script. Copy object so the userscript wont change them as they will
    # be needed for the draw_world python script.
    response = requests.get(url = (URL + "/" + client_config["username"] + "/" + client_config["password"] + "/" + action)).json()

    # This will provide the user with useful info while writing their script. You can turn this off in the client_config.json file.

    if client_config["enable_gui"] == True:
        draw_world.draw(response, client_config) # draw gui for the player before checking response from action.
        k = cv2.waitKey(30) & 0xff # Need this so cv2 window won't freeze.
        if k == 27:
            break
    
    if not response["login_status"] == "successful":
        print("[ALERT] login_status : " + response["login_status"])
    

